//
//  Music.swift
//  AppBienEtre
//
//  Created by Jesus Bizarro on 06/02/2021.
//

import SwiftUI




struct Music: View {
    @State var count = 1
    var body: some View {
        ZStack {
            Color.white
                .edgesIgnoringSafeArea(.all)
            VStack {
                HStack {
                    Text("MusicPlayer").font(.system(size: 45)).fontWeight(.bold).foregroundColor(.butonColor)
                }
                HStack {
                    
                    Spacer()
                    Button(action: {
                        if self.count < 5 {
                            self.count += 1
                        } else {
                            self.count = 1
                        }
                            MyMusicPlayer.shared.start(song: self.count)
                        
                    }) {
                        Image(systemName: "restart").resizable()
                            .frame(width: 45, height: 45)
                            .aspectRatio(contentMode: .fill)
                            .foregroundColor(.butonColor)
                }
                    
                    
                    Spacer()
                    Button(action: {
                        MyMusicPlayer.shared.play()
                    }) {
                        Image(systemName: "play.circle.fill").resizable()
                            .frame(width: 50, height: 50)
                            .aspectRatio(contentMode: .fill)
                            .foregroundColor(.butonColor)
                        
                    }
                        Spacer()
                        Button(action: {
                            MyMusicPlayer.shared.pause()
                        }) {
                            Image(systemName: "pause.circle.fill").resizable()
                                .frame(width: 50, height: 50)
                                .aspectRatio(contentMode: .fill)
                                .foregroundColor(.butonColor)
                            
                        }
                        Spacer()
                        Button(action: {
                            if self.count < 5 {
                                self.count += 1
                            } else {
                                self.count = 1
                            }
                            MyMusicPlayer.shared.start(song: self.count)
                            
                        }) {
                            Image(systemName: "forward.end").resizable()
                                .frame(width: 45, height: 45)
                                .aspectRatio(contentMode: .fill)
                                .foregroundColor(.butonColor)
                    }
                    Spacer()
                }
                
            }
        }//end ZStack
            
        .onAppear {
            
            MyMusicPlayer.shared.start(song: 1)
        
        }
        
        
    }
}

struct Music_Previews: PreviewProvider {
    static var previews: some View {
        Music()
    }
}

//

