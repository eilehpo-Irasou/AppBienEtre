//
//  AppBienEtreApp.swift
//  AppBienEtre
//
//  Created by Ophelie Castaner on 02/02/2021.
//

import SwiftUI

@main
struct AppBienEtreApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
