//
//  MyMusicPlayer.swift
//  AppBienEtre
//
//  Created by Jesus Bizarro on 08/02/2021.
//

import Foundation
import AVKit


class MyMusicPlayer {
    
    static let shared = MyMusicPlayer()
    
    private var audioPlayer: AVAudioPlayer!
    
    func start(song: Int) {
        let sound = Bundle.main.path(forResource: "song\(song)", ofType: "mp3")!
        self.audioPlayer = try! AVAudioPlayer(contentsOf: URL(fileURLWithPath: sound))
        self.audioPlayer.play()
    }
    
    func play() {
        self.audioPlayer.play()
    }
    
    func pause() {
        self.audioPlayer.pause()
    }
}


